#MainLoop of motion detection
#Version 1.0
#date 13 Jun 2018
#by Xiaodong Wu and Lin Weizhe
#
from optical_flow_interface import *
from TraceMaker import *
import time
import cv2
from MainDetection import *
import numpy as np

'''Video Initiation'''
# open the camera for warming up
# cap = cv2.VideoCapture('http://192.168.0.100:8080')
cap = cv2.VideoCapture("demo_video_final.avi")

# grab the first frame
old_frame = get_frame_from(cap)

# create tracer
trace_maker = TraceMaker(old_frame)

# create tackbar
def nothing(x):
    pass
cv2.imshow('video', old_frame)
cv2.createTrackbar('S', 'video', 0, 255, nothing)
cv2.setTrackbarPos('S','video', 90)


'''Do initial trace finding'''
# set time for the trace finding module
t_trace_finding = float(input('input time for trace finding: \n'))
start = time.time()

# start initial trace making
while time.time() - start <= t_trace_finding:
    # read the current frame
    cur_frame = get_frame_from(cap)

    # stop when fail to get one frame
    if type(cur_frame) is bool:
        break

    # create backups
    display_frame = np.array(cur_frame)

    '''using Frame Difference to do detection'''
    S = cv2.getTrackbarPos('S', 'video')
    boxes1, boxes2, bboxes = getMainDetection(old_frame, cur_frame, S, (0, 0, 50, 50), None, False)

    '''Drawing on the frequency map'''
    trace_maker.update_freq(bboxes)

    '''Draw bbox'''
    print_bboxes(display_frame, bboxes)

trace_maker.disp()
trace_maker.enhance_traces()
trace_maker.disp()

'''Video Initiation'''
# grab the first frame
old_frame = get_frame_from(cap)

'''Start actual tracing'''
while True:
    # Record FPS
    timer = cv2.getTickCount()

    # read the current frame
    cur_frame = get_frame_from(cap)

    # stop when fail to get one frame
    if type(cur_frame) is bool:
        break

    # create backups
    display_frame = np.array(cur_frame)

    '''using Frame Difference to do detection'''
    S = cv2.getTrackbarPos('S', 'video')
    boxes1, boxes2, bboxes = getMainDetection(old_frame, cur_frame, S, (0, 0, 50, 50), trace_maker.freq_map, True)

    '''Drawing on the frequency map'''
    #trace_maker.update_freq(bboxes)

    '''Draw bbox'''
    print_bboxes(display_frame, bboxes)

    '''Show cur frame'''
    # Calculate Frames per second (FPS)
    fps = cv2.getTickFrequency() / (cv2.getTickCount() - timer)
    # Display FPS on frame
    cv2.putText(cur_frame, "FPS : " + str(int(fps)), (100, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (50, 170, 50), 2);
    # display cur frame
    cv2.imshow('video', display_frame)
    # waitkey for trackbar pause
    a = cv2.waitKey(1)
    if a == ord('q'):
        break
    elif a == ord('z'):
        cv2.waitKey(1000)
